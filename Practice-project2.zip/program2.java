package phase1;
class modelcar
{
	String model= "audi";
	String color="white";
	int range =100;
	protected void display(){	 
	System.out.println("model is "+model+"\ncolor is"+color+"\nrange is "+range );
	 }
	
}
class b extends modelcar{}
public class program2 {

	public static void main(String[] args) {
		b bb=new b();
		bb.display();
	}

}
