package phase1;

import java.util.Scanner;

public class program1 {
public static void main(String args[])
{
	char c='f';
	System.out.println("implicit type casting ");
	int v = c;
	System.out.println("value of c is "+ v);
	Scanner sc = new Scanner(System.in);
		int k= sc.nextInt();
		char a= (char)k;
		System.out.println("explicit type conversion ");
		System.out.println("value of a is  "+ a);
				
}
}
