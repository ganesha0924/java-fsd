package phase1;
import java.lang.reflect.Modifier;
public class program7 {
public static void main(String[] args)
{
program7 p7 = new program7() {};
class LocalInnerClass {}
LocalInnerClass innerClass = new LocalInnerClass();
Class classInstance1 = p7.getClass();
Class classInstance2 = innerClass.getClass();
boolean isNested1= classInstance1.getEnclosingClass() != null;
boolean isNested2= classInstance2.getEnclosingClass() != null;
boolean isStatic1 = Modifier.isStatic(
classInstance1.getModifiers());
boolean isStatic2 = Modifier.isStatic(
classInstance2.getModifiers());
System.out.println("is program7an inner class object? : "+ (isNested1 && !isStatic1));
System.out.println("is innerClass an inner class object? : "+ (isNested2 && !isStatic2));
		}
	}


