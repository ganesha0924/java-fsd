package phase1;
import java.util.*;  	 

public class program6 {
 
 public static void main(String args[]) {    
 
 HashMap<Integer, String> map = new HashMap<Integer, String>();           
 
 map.put(1,"telugu");
 
 map.put(2, "tamil"); 
 
 map.put(3, "hindi");  
 
 map.put(4, "marati");
 
 map.put(5, "kanada");
 
 System.out.println("lanugaes arev"+ map);    
 
 map.remove(5);  
 
 System.out.println("after removing value list is "+ map);
	   }
	
}
