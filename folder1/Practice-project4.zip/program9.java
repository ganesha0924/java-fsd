package phase1;
import java.util.*;

public class program9 {
public static void main(String[] args){ 
int ar1[] = {10,20,30,40,50,80,50,100};

 int ar2[] = {10,20,30};

 Arrays.sort(ar1);

 int k= 100;

 System.out.println("searching value");
 
 System.out.println( " value found at "+ Arrays.binarySearch(ar1, k));
 
 System.out.println("comparing arrays");
 
 System.out.println(Arrays.compare(ar1, ar2));
 
	    }
	}

