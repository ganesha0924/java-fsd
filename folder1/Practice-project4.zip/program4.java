package phase1;

public class program4 {
		String car;

		 // constructors with default , parameters 
		  program4() {
		    this.car= "audi";
		  }

		  
		  program4(String car) {
		    this.car = car;
		  }

		  public void getName() {
		    System.out.println("car model is " + this.car);
		  }

		  public static void main(String[] args) {

		   
		    program4 p1 = new program4();

		   
		    program4 p2 = new program4("BMW");

		    p1.getName();
		    p2.getName();
		  }
		
}
