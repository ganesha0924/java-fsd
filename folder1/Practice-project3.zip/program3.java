package phase1;

public class program3 {
	public  int addition(int a,int b)// passing parameters
	{
	    int c = a+b;
		return c;
	}
	public  void display(int c)
	{
		
	//System.out.println("value  c is "+ c);
	}
	public static void main(String args[])
			{
		program3 obj=new program3();
		int c=obj.addition(10, 20);
		System.out.println(c);
		
			
			}
}

