package org.example.virtualkey.screens;
public interface Screen {
public void Display();
public void Options(int option);
public void userInput();
}
