package phase1;
class program171 extends Exception{
	   String str1;
	   program171(String str2) {
		str1=str2;
	   }
	   public String toString(){ 
		return ("MyException Occurred: "+str1) ;
	   }
	}
	class program17{
	   public static void main(String args[]){
		try{
			System.out.println("Starting of try block");
			// I'm throwing the custom exception using throw
			throw new program171("This is My error Message");
		}
		catch(program171 exp){
			System.out.println("Catch Block") ;
			System.out.println(exp) ;
		}
	   }
	}
