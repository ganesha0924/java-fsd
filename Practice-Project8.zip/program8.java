package phase1;
import java.io.*;
public class program8 {
 public static void main(String[] args) {
 String str[] = {"converting","string","to","stringbuilder"};
 
 StringBuilder sb1 = new StringBuilder();
 
 String str1 = "converting string to";
 
 StringBuffer sb = new StringBuffer();
 
 sb.append(str1);
 
 String str2 = " string buffer";
 
 sb.append(str2);
 
 System.out.println(sb);
 
 sb1.append(str[0]);
 
 sb1.append(str[1]);
 
 sb1.append(str[2]);
 
 sb1.append(str[3]);
 
 System.out.println(sb1);
 
	    }
	}

