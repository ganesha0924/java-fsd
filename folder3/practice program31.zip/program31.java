package phase1;
import java.util.Arrays;
public class program31{    
public static int linearSearch(int[] arr, int key){
	System.out.println("linear search");
        for(int i=0;i<arr.length;i++){    
            if(arr[i] == key){    
                return i;    
            }    
        }    
        return -1;    
    }    
public static void binarySearch(int arr[], int first, int last, int key){ 
	System.out.println("binary search");
	   int mid = (first + last)/2;  
	   while( first <= last ){  
	      if ( arr[mid] < key ){  
	        first = mid + 1;     
	      }else if ( arr[mid] == key ){  
	        System.out.println("Element is found at index: " + mid);  
	        break;  
	      }else{  
	         last = mid - 1;  
	      }  
	      mid = (first + last)/2;  
	   }  
	   if ( first > last ){  
	      System.out.println("Element is not found!");  
	   }  
	 }  
static int exponentialSearch(int arr[],
        int n, int x)
{
if (arr[0] == x)
return 0;
int i = 1;
while (i < n && arr[i] <= x)
i = i*2;
return Arrays.binarySearch(arr, i/2, 
     Math.min(i, n-1), x);
}
    public static void main(String a[]){    
        int[] a1= {10,20,30,50,70,90};    
        int key = 50;   
        int last=a1.length-1;  
        binarySearch(a1,0,last,key);    
        System.out.println(key+" is found at index: "+linearSearch(a1, key));
    	System.out.println("exponential search ");
        int x = 70;
        int result = exponentialSearch(a1, 
                                  a1.length, x);
          
        System.out.println((result < 0) ? 
          "Element is not present in array" :
          "Element is present at index " + 
                             result);
        
    }    
}    